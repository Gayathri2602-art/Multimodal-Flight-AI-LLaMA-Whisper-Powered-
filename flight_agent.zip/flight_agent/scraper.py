"""
scraper.py
----------
Works in both VS Code (CLI) and Google Colab (imported as module).
Uses fast-flights get_flights() — correct prices, no manual JS parsing.

Install:
    pip install "fast-flights @ git+https://github.com/AWeirdDev/flights.git@dev" pandas

VS Code:
    python scraper.py --from "Mumbai" --to "Delhi" --date 2025-08-15
    python scraper.py --interactive

Colab:
    import scraper
    flights = scraper.scrape("Mumbai", "Delhi", "2025-08-15")
"""

import argparse
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

try:
    from fast_flights import FlightQuery, Passengers, create_query, get_flights
except ImportError:
    print("ERROR: fast-flights not installed.")
    print("Run: pip install 'fast-flights @ git+https://github.com/AWeirdDev/flights.git@dev'")
    sys.exit(1)

# ── Config ────────────────────────────────────────────────────
CACHE_DIR    = Path("flight_cache")
AIRPORTS_CSV = Path("airports.csv")
CACHE_DIR.mkdir(exist_ok=True)

# ── IATA lookup ───────────────────────────────────────────────
IATA_OVERRIDES = {
    "mumbai": "BOM", "bombay": "BOM",
    "delhi": "DEL", "new delhi": "DEL",
    "bangalore": "BLR", "bengaluru": "BLR", "banglore": "BLR",
    "hyderabad": "HYD", "hyd": "HYD",
    "chennai": "MAA", "madras": "MAA",
    "kolkata": "CCU", "calcutta": "CCU",
    "goa": "GOI", "panaji": "GOI",
    "pune": "PNQ", "ahmedabad": "AMD",
    "jaipur": "JAI", "kochi": "COK", "cochin": "COK",
    "lucknow": "LKO", "nagpur": "NAG", "indore": "IDR",
    "bhubaneswar": "BBI", "vizag": "VTZ", "visakhapatnam": "VTZ",
    "surat": "STV", "amritsar": "ATQ", "varanasi": "VNS",
    "patna": "PAT", "ranchi": "IXR", "guwahati": "GAU",
    "coimbatore": "CJB", "thiruvananthapuram": "TRV", "trivandrum": "TRV",
    "mangalore": "IXE", "chandigarh": "IXC",
    "london": "LHR", "paris": "CDG", "dubai": "DXB",
    "singapore": "SIN", "new york": "JFK", "nyc": "JFK",
    "tokyo": "NRT", "bangkok": "BKK", "sydney": "SYD",
    "melbourne": "MEL", "toronto": "YYZ", "amsterdam": "AMS",
    "frankfurt": "FRA", "kuala lumpur": "KUL", "hong kong": "HKG",
    "doha": "DOH", "abu dhabi": "AUH", "muscat": "MCT",
    "riyadh": "RUH", "jeddah": "JED", "kuwait": "KWI",
    "miami": "MIA", "los angeles": "LAX", "chicago": "ORD",
    "san francisco": "SFO", "seattle": "SEA", "boston": "BOS",
    "washington": "IAD", "atlanta": "ATL", "denver": "DEN",
    "dallas": "DFW", "houston": "IAH", "phoenix": "PHX",
    "orlando": "MCO", "las vegas": "LAS", "new orleans": "MSY",
    "nashville": "BNA", "austin": "AUS",
    "beijing": "PEK", "shanghai": "PVG", "seoul": "ICN",
    "istanbul": "IST", "moscow": "SVO", "rome": "FCO",
    "madrid": "MAD", "barcelona": "BCN", "zurich": "ZRH",
    "vienna": "VIE", "brussels": "BRU", "copenhagen": "CPH",
    "stockholm": "ARN", "oslo": "OSL", "helsinki": "HEL",
    "athens": "ATH", "cairo": "CAI", "nairobi": "NBO",
    "johannesburg": "JNB", "lagos": "LOS", "casablanca": "CMN",
    "mexico city": "MEX", "sao paulo": "GRU", "buenos aires": "EZE",
    "lima": "LIM", "bogota": "BOG", "santiago": "SCL",
    "taipei": "TPE", "manila": "MNL", "jakarta": "CGK",
    "karachi": "KHI", "lahore": "LHE", "dhaka": "DAC",
    "colombo": "CMB", "kathmandu": "KTM",
    "tel aviv": "TLV", "amman": "AMM", "beirut": "BEY",
}

_csv_city_to_iata = {}
_csv_name_to_iata = {}

if AIRPORTS_CSV.exists():
    try:
        _cols = ["code","time_zone_id","name","city_code","country_id",
                 "location","elevation","url","icao","city","county","state"]
        _ap = pd.read_csv(AIRPORTS_CSV, names=_cols, header=0,
                          on_bad_lines="skip", encoding="utf-8")
        _ap = _ap.dropna(subset=["code"])
        _ap["code"] = _ap["code"].str.strip().str.upper()
        _ap["name"] = _ap["name"].fillna("").str.strip()
        _ap["city"] = _ap["city"].fillna("").str.strip()
        for _, row in _ap[_ap["name"].str.upper().str.contains("AIRPORT", na=False)].iterrows():
            k = row["city"].lower().strip()
            if k and k not in _csv_city_to_iata:
                _csv_city_to_iata[k] = row["code"]
        for _, row in _ap.iterrows():
            k = row["name"].lower().strip()
            if k:
                _csv_name_to_iata[k] = row["code"]
        print(f"airports.csv loaded: {len(_ap)} airports")
    except Exception as e:
        print(f"Warning: airports.csv error: {e}")


def city_to_iata(city_name: str) -> str:
    if not city_name:
        raise ValueError("Empty city name")
    raw   = city_name.strip()
    lower = raw.lower()
    if len(raw) == 3 and raw.isalpha():
        return raw.upper()
    if lower in IATA_OVERRIDES:
        return IATA_OVERRIDES[lower]
    if lower in _csv_city_to_iata:
        return _csv_city_to_iata[lower]
    if lower in _csv_name_to_iata:
        return _csv_name_to_iata[lower]
    for city_key, code in _csv_city_to_iata.items():
        if lower in city_key or city_key in lower:
            return code
    code = raw.upper()[:3]
    print(f"Warning: no IATA match for '{city_name}', using '{code}'")
    return code


# ── Date parsing ──────────────────────────────────────────────
def parse_date(raw: str) -> str:
    raw = raw.strip().lower()
    if re.match(r"^\d{4}-\d{2}-\d{2}$", raw):
        return raw
    if raw == "tomorrow":
        return (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    if raw == "today":
        return datetime.now().strftime("%Y-%m-%d")
    MONTHS = {
        "jan":1,"january":1,"feb":2,"february":2,"mar":3,"march":3,
        "apr":4,"april":4,"may":5,"jun":6,"june":6,"jul":7,"july":7,
        "aug":8,"august":8,"sep":9,"sept":9,"september":9,
        "oct":10,"october":10,"nov":11,"november":11,"dec":12,"december":12,
    }
    m = re.match(r"(\d{1,2})(?:st|nd|rd|th)?\s+([a-z]+)(?:\s+(\d{4}))?", raw)
    if m:
        day, mon = int(m.group(1)), MONTHS.get(m.group(2))
        if mon:
            yr = int(m.group(3)) if m.group(3) else datetime.now().year
            try:
                dt = datetime(yr, mon, day)
                if dt < datetime.now():
                    dt = datetime(yr + 1, mon, day)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                pass
    m = re.match(r"([a-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s+(\d{4}))?", raw)
    if m:
        mon, day = MONTHS.get(m.group(1)), int(m.group(2))
        if mon:
            yr = int(m.group(3)) if m.group(3) else datetime.now().year
            try:
                dt = datetime(yr, mon, day)
                if dt < datetime.now():
                    dt = datetime(yr + 1, mon, day)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                pass
    m = re.match(r"(\d{1,2})[/\-](\d{1,2})[/\-](\d{2,4})", raw)
    if m:
        d, mo, yr = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if yr < 100:
            yr += 2000
        try:
            return datetime(yr, mo, d).strftime("%Y-%m-%d")
        except ValueError:
            pass
    raise ValueError(f"Cannot parse date: '{raw}'")


# ── Safe datetime formatter ───────────────────────────────────
def fmt_dt(dt) -> str:
    """
    Convert SimpleDatetime to string.
    Google sometimes returns zero/empty date for some legs —
    return N/A instead of crashing or showing 0000-00-00.
    """
    try:
        d = dt.date   # tuple (year, month, day)
        t = dt.time   # tuple (hour, minute)
        # zero date = Google didn't include it in payload
        if not d or len(d) < 3 or (d[0] == 0 and d[1] == 0 and d[2] == 0):
            return "N/A"
        if not t or len(t) < 2:
            return f"{d[0]}-{d[1]:02d}-{d[2]:02d}"
        return f"{d[0]}-{d[1]:02d}-{d[2]:02d} {t[0]:02d}:{t[1]:02d}"
    except Exception:
        return "N/A"


# ── Cache ─────────────────────────────────────────────────────
def cache_path(departure: str, destination: str, date: str) -> Path:
    dep = departure.lower().replace(" ", "_")
    dst = destination.lower().replace(" ", "_")
    return CACHE_DIR / f"{dep}_to_{dst}_{date}.csv"


# ── Core scrape function ──────────────────────────────────────
def scrape(
    departure: str,
    destination: str,
    date: str,
    trip: str = "one-way",
    seat: str = "economy",
    adults: int = 1,
    use_cache: bool = True,
    max_retries: int = 3,
) -> list:
    """
    Scrape Google Flights using fast-flights get_flights().

    Returns list of dicts with keys:
        airline, price, price_str, departure_str, arrival_str,
        duration, duration_min, stops, stops_raw,
        from_code, to_code, travel_date, plane, carbon_g

    Saves CSV to CACHE_DIR automatically.
    In Colab: set scraper.CACHE_DIR = Path('/content/drive/MyDrive/flight_agent/flight_cache')
    """
    date = parse_date(date)

    # Cache check
    path = cache_path(departure, destination, date)
    if use_cache and path.exists():
        df = pd.read_csv(path)
        print(f"Cache hit: {path.name} ({len(df)} flights)")
        return df.to_dict(orient="records")

    dep_code  = city_to_iata(departure)
    dest_code = city_to_iata(destination)

    trip_map = {
        "one way": "one-way", "one-way": "one-way", "oneway": "one-way",
        "round trip": "round-trip", "round-trip": "round-trip", "return": "round-trip",
        "multi city": "multi-city", "multi-city": "multi-city",
    }
    trip_key = trip_map.get(trip.lower().strip(), "one-way")

    print(f"\nScraping: {departure} ({dep_code}) -> {destination} ({dest_code})")
    print(f"Date: {date}  Trip: {trip_key}  Seat: {seat}  Adults: {adults}")

    query = create_query(
        flights=[FlightQuery(date=date, from_airport=dep_code, to_airport=dest_code)],
        seat=seat,
        trip=trip_key,
        passengers=Passengers(adults=adults),
        language="en-US",
    )
    print(f"URL: {query.url()}\n")

    last_error = None
    for attempt in range(1, max_retries + 1):
        print(f"Attempt {attempt}/{max_retries}...")
        try:
            # Uses fast-flights get_flights() — returns correct prices
            result = get_flights(query)

            rows = []
            for f in result:
                legs      = f.flights
                stops     = max(0, len(legs) - 1)
                total_min = sum(lg.duration for lg in legs)
                first     = legs[0]
                last_leg  = legs[-1]

                price = (f.price * 100) if f.price else 0

                rows.append({
                    "airline":       ", ".join(f.airlines) if f.airlines else "Unknown",
                    "price":         price,
                    "price_str":     f"Rs.{price:,}" if price else "N/A",
                    "departure_str": fmt_dt(first.departure),
                    "arrival_str":   fmt_dt(last_leg.arrival),
                    "duration":      f"{total_min // 60}h {total_min % 60}m",
                    "duration_min":  total_min,
                    "stops":         "Non-stop" if stops == 0 else f"{stops} stop(s)",
                    "stops_raw":     stops,
                    "from_code":     dep_code,
                    "to_code":       dest_code,
                    "travel_date":   date,
                    "plane":         first.plane_type or "",
                    "carbon_g":      f.carbon.emission if f.carbon else 0,
                })

            if not rows:
                print("  0 flights returned. Try a date 7-30 days from today.")
                last_error = "0 flights returned"
                continue

            df = pd.DataFrame(rows)
            df.to_csv(path, index=False)
            print(f"\nFound {len(df)} flights -> {path.name}")

            print("\nTop 5 cheapest:")
            for _, r in df.nsmallest(5, "price").iterrows():
                print(
                    f"  {str(r['airline']):<30} "
                    f"{r['departure_str']} -> {r['arrival_str']}  "
                    f"{r['duration']:<8}  {r['stops']:<12}  {r['price_str']}"
                )

            return df.to_dict(orient="records")

        except Exception as e:
            last_error = e
            print(f"  Error: {str(e)[:100]}")
            if attempt < max_retries:
                print("  Retrying...")

    raise RuntimeError(
        f"All {max_retries} attempts failed. Last: {last_error}\n"
        f"Try a date 7-30 days from today. Route: {dep_code}->{dest_code} on {date}"
    )


# ── Interactive mode (VS Code only) ──────────────────────────
def interactive_mode():
    print("\n=== Google Flights Scraper ===\n")
    departure   = input("Departure city: ").strip()
    destination = input("Destination city: ").strip()
    date_raw    = input("Date (YYYY-MM-DD / tomorrow / '20 june'): ").strip()
    trip        = input("Trip [one-way/round-trip] (default one-way): ").strip() or "one-way"
    seat        = input("Seat [economy/business/first] (default economy): ").strip() or "economy"
    adults_raw  = input("Adults (default 1): ").strip()
    adults      = int(adults_raw) if adults_raw.isdigit() else 1
    scrape(departure, destination, date_raw, trip=trip, seat=seat, adults=adults)

def fmt_dt(dt) -> str:
    """
    Convert SimpleDatetime to string safely.
    Handles missing minutes (e.g. [17] instead of [17, 0])
    and zero/empty dates from Google's payload.
    """
    try:
        d = dt.date   # (year, month, day)
        t = dt.time   # (hour,) or (hour, minute) - minute sometimes missing

        # zero date = Google didn't include it
        if not d or len(d) < 3 or (d[0] == 0 and d[1] == 0 and d[2] == 0):
            return "N/A"

        # Build time string - handle missing minutes
        if not t or len(t) == 0:
            time_str = "00:00"
        elif len(t) == 1:
            time_str = f"{t[0]:02d}:00"   # e.g. [17] -> "17:00"
        else:
            time_str = f"{t[0]:02d}:{t[1]:02d}"

        return f"{d[0]}-{d[1]:02d}-{d[2]:02d} {time_str}"
    except Exception:
        return "N/A"
        
# ── CLI (VS Code only) ────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description="Scrape Google Flights -> CSV",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  python scraper.py --from "Mumbai" --to "Delhi" --date 2025-08-15
  python scraper.py --from "London" --to "Dubai" --date "20 june 2025" --seat business
  python scraper.py --interactive
        """,
    )
    ap.add_argument("--from",        dest="departure")
    ap.add_argument("--to",          dest="destination")
    ap.add_argument("--date")
    ap.add_argument("--trip",        default="one-way")
    ap.add_argument("--seat",        default="economy")
    ap.add_argument("--adults",      default=1, type=int)
    ap.add_argument("--no-cache",    action="store_true")
    ap.add_argument("--interactive", action="store_true")
    args = ap.parse_args()

    if args.interactive or not args.departure:
        interactive_mode()
        return

    if not args.destination: ap.error("--to is required")
    if not args.date:        ap.error("--date is required")

    scrape(
        departure=args.departure,
        destination=args.destination,
        date=args.date,
        trip=args.trip,
        seat=args.seat,
        adults=args.adults,
        use_cache=not args.no_cache,
    )


if __name__ == "__main__":
    main()
